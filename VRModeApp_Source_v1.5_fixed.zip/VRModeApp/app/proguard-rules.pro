# Keep Accessibility and Service classes
-keep class com.vrmode.app.service.** { *; }
-keep class com.vrmode.app.control.** { *; }
