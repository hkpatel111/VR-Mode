package com.vrmode.app.vr

import android.graphics.Color
import kotlin.math.max
import kotlin.math.min

/**
 * Dynamic lighting that reacts to the average brightness / dominant color
 * of the current screen content (from MediaProjection frames).
 *
 * The controller exposes ambient color + intensity that the SBSRenderer
 * (or environment shader) can use to tint the virtual world.
 */
class DynamicLightingController {

    data class LightState(
        val ambientR: Float,
        val ambientG: Float,
        val ambientB: Float,
        val intensity: Float,       // 0..1
        val warmth: Float           // -1 (cool) .. +1 (warm)
    )

    private var current = LightState(0.15f, 0.15f, 0.18f, 0.4f, 0f)
    private val smoothing = 0.12f

    /**
     * Feed average color sampled from the captured frame.
     * r,g,b in 0..1 range.
     */
    fun updateFromFrameAverage(r: Float, g: Float, b: Float) {
        val luminance = 0.2126f * r + 0.7152f * g + 0.0722f * b
        val warmth = ((r - b) * 1.5f).coerceIn(-1f, 1f)

        // Target ambient follows content but stays relatively dark so screen remains focus
        val targetIntensity = (0.25f + luminance * 0.55f).coerceIn(0.2f, 0.85f)
        val targetR = (0.08f + r * 0.35f)
        val targetG = (0.08f + g * 0.35f)
        val targetB = (0.10f + b * 0.35f)

        current = LightState(
            ambientR = lerp(current.ambientR, targetR, smoothing),
            ambientG = lerp(current.ambientG, targetG, smoothing),
            ambientB = lerp(current.ambientB, targetB, smoothing),
            intensity = lerp(current.intensity, targetIntensity, smoothing),
            warmth = lerp(current.warmth, warmth, smoothing)
        )
    }

    fun getState(): LightState = current

    /** Convenience: pack as Color int for debugging / UI */
    fun getAmbientColorInt(): Int {
        val s = current
        val r = (s.ambientR * 255).toInt().coerceIn(0, 255)
        val g = (s.ambientG * 255).toInt().coerceIn(0, 255)
        val b = (s.ambientB * 255).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
}
