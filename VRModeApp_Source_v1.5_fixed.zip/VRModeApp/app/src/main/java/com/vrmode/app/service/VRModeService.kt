package com.vrmode.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.vrmode.app.R
import com.vrmode.app.VRModeApp
import com.vrmode.app.ui.MainActivity
import com.vrmode.app.utils.PrefsManager

/**
 * Core foreground service that keeps VR Mode running.
 * Handles MediaProjection session, notification, and state.
 *
 * Note: Full stereoscopic OpenGL rendering pipeline is marked as TODO
 * for the next development iteration (requires significant native/GL work).
 */
class VRModeService : Service() {

    companion object {
        const val TAG = "VRModeService"
        const val ACTION_START = "com.vrmode.app.action.START_VR"
        const val ACTION_STOP = "com.vrmode.app.action.STOP_VR"
        const val ACTION_UPDATE = "com.vrmode.app.action.UPDATE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        const val NOTIFICATION_ID = 1001

        var isRunning = false
            private set
    }

    private var mediaProjection: MediaProjection? = null
    private var mediaProjectionManager: MediaProjectionManager? = null

    override fun onCreate() {
        super.onCreate()
        mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
                if (resultCode == Activity.RESULT_OK && data != null) {
                    startVRMode(resultCode, data)
                } else {
                    Log.e(TAG, "Invalid MediaProjection data")
                    stopSelf()
                }
            }
            ACTION_STOP -> stopVRMode()
            ACTION_UPDATE -> {
                // Placeholder for recenter logic
                Log.d(TAG, "Recenter requested")
            }
        }
        return START_STICKY
    }

    private fun startVRMode(resultCode: Int, data: Intent) {
        if (isRunning) return

        try {
            mediaProjection = mediaProjectionManager?.getMediaProjection(resultCode, data)
            // TODO: Create VirtualDisplay + SurfaceTexture + OpenGL SBS renderer here
            // For now we keep the projection alive and show notification.

            isRunning = true
            PrefsManager.setVREnabled(true)

            val notification = buildNotification(true)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }

            Log.i(TAG, "VR Mode started")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start VR Mode", e)
            stopSelf()
        }
    }

    private fun stopVRMode() {
        mediaProjection?.stop()
        mediaProjection = null
        isRunning = false
        PrefsManager.setVREnabled(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        Log.i(TAG, "VR Mode stopped")
    }

    private fun buildNotification(isOn: Boolean): Notification {
        val stopIntent = Intent(this, VRModeService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this, 1, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val envName = PrefsManager.getCurrentEnvironment()

        return NotificationCompat.Builder(this, VRModeApp.CHANNEL_ID)
            .setContentTitle(if (isOn) getString(R.string.notification_title_on) else getString(R.string.notification_title_off))
            .setContentText(envName)
            .setSmallIcon(R.drawable.ic_vr_mode)
            .setContentIntent(openPending)
            .setOngoing(isOn)
            .setOnlyAlertOnce(true)
            .addAction(0, getString(R.string.action_turn_off), stopPending)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopVRMode()
        super.onDestroy()
    }
}
