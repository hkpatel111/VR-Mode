package com.vrmode.app.utils

import org.json.JSONObject

/**
 * Simple multi-profile system.
 * Each profile stores its own environment, screen, control and comfort settings.
 */
object ProfileManager {

    private const val KEY_PROFILES = "profiles_json"
    private const val KEY_ACTIVE_PROFILE = "active_profile_id"
    private const val DEFAULT_ID = "default"

    data class Profile(
        val id: String,
        val name: String,
        val environment: String = "Classic Movie Theater",
        val screenSize: Int = 70,
        val screenDistance: Int = 50,
        val curved: Boolean = true,
        val nightMode: Boolean = false,
        val autoHideControls: Boolean = true,
        val ambientVolume: Float = 0.4f,
        val enableJoystick: Boolean = true,
        val enableVolumeButtons: Boolean = true,
        val enableHeadGestures: Boolean = false,
        val enableVoice: Boolean = false
    )

    fun getActiveProfileId(): String =
        PrefsManager.getString(KEY_ACTIVE_PROFILE, DEFAULT_ID)

    fun setActiveProfileId(id: String) =
        PrefsManager.putString(KEY_ACTIVE_PROFILE, id)

    fun getAllProfiles(): List<Profile> {
        val json = PrefsManager.getString(KEY_PROFILES, "")
        if (json.isBlank()) {
            val default = Profile(DEFAULT_ID, "Default")
            saveAll(listOf(default))
            return listOf(default)
        }
        return try {
            val arr = org.json.JSONArray(json)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Profile(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    environment = o.optString("environment", "Classic Movie Theater"),
                    screenSize = o.optInt("screenSize", 70),
                    screenDistance = o.optInt("screenDistance", 50),
                    curved = o.optBoolean("curved", true),
                    nightMode = o.optBoolean("nightMode", false),
                    autoHideControls = o.optBoolean("autoHideControls", true),
                    ambientVolume = o.optDouble("ambientVolume", 0.4).toFloat(),
                    enableJoystick = o.optBoolean("enableJoystick", true),
                    enableVolumeButtons = o.optBoolean("enableVolumeButtons", true),
                    enableHeadGestures = o.optBoolean("enableHeadGestures", false),
                    enableVoice = o.optBoolean("enableVoice", false)
                )
            }
        } catch (e: Exception) {
            listOf(Profile(DEFAULT_ID, "Default"))
        }
    }

    fun getActiveProfile(): Profile {
        val id = getActiveProfileId()
        return getAllProfiles().find { it.id == id } ?: getAllProfiles().first()
    }

    fun saveProfile(profile: Profile) {
        val list = getAllProfiles().toMutableList()
        val idx = list.indexOfFirst { it.id == profile.id }
        if (idx >= 0) list[idx] = profile else list.add(profile)
        saveAll(list)
    }

    fun createProfile(name: String): Profile {
        val id = "profile_${System.currentTimeMillis()}"
        val p = Profile(id, name)
        saveProfile(p)
        return p
    }

    fun deleteProfile(id: String) {
        if (id == DEFAULT_ID) return
        val list = getAllProfiles().filter { it.id != id }
        saveAll(list)
        if (getActiveProfileId() == id) setActiveProfileId(DEFAULT_ID)
    }

    fun applyProfileToPrefs(profile: Profile) {
        PrefsManager.setCurrentEnvironment(profile.environment)
        PrefsManager.putInt(PrefsManager.KEY_SCREEN_SIZE, profile.screenSize)
        PrefsManager.putInt(PrefsManager.KEY_SCREEN_DISTANCE, profile.screenDistance)
        PrefsManager.putBoolean(PrefsManager.KEY_CURVED, profile.curved)
        PrefsManager.putBoolean(PrefsManager.KEY_NIGHT_MODE, profile.nightMode)
        PrefsManager.putBoolean(PrefsManager.KEY_AUTO_HIDE_CONTROLS, profile.autoHideControls)
        PrefsManager.putFloat(PrefsManager.KEY_AMBIENT_VOLUME, profile.ambientVolume)
        PrefsManager.putBoolean(PrefsManager.KEY_ENABLE_JOYSTICK, profile.enableJoystick)
        PrefsManager.putBoolean(PrefsManager.KEY_ENABLE_VOLUME_BUTTONS, profile.enableVolumeButtons)
        PrefsManager.putBoolean(PrefsManager.KEY_ENABLE_HEAD_GESTURES, profile.enableHeadGestures)
        PrefsManager.putBoolean(PrefsManager.KEY_ENABLE_VOICE, profile.enableVoice)
    }

    private fun saveAll(list: List<Profile>) {
        val arr = org.json.JSONArray()
        list.forEach { p ->
            arr.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("environment", p.environment)
                put("screenSize", p.screenSize)
                put("screenDistance", p.screenDistance)
                put("curved", p.curved)
                put("nightMode", p.nightMode)
                put("autoHideControls", p.autoHideControls)
                put("ambientVolume", p.ambientVolume.toDouble())
                put("enableJoystick", p.enableJoystick)
                put("enableVolumeButtons", p.enableVolumeButtons)
                put("enableHeadGestures", p.enableHeadGestures)
                put("enableVoice", p.enableVoice)
            })
        }
        PrefsManager.putString(KEY_PROFILES, arr.toString())
    }
}
