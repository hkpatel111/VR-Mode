package com.vrmode.app.vr

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * Placeholder for the full-screen stereoscopic VR rendering surface.
 * In future builds this will host the OpenGL ES / Vulkan SBS renderer
 * that displays the MediaProjection output with lens distortion.
 */
class VRDisplayActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // TODO: Attach GLSurfaceView + dual-eye cameras + distortion shader
        finish() // not used in current core build
    }
}
