package com.vrmode.app.vr

import android.content.Context
import android.opengl.GLSurfaceView
import android.util.AttributeSet
import android.view.MotionEvent
import com.vrmode.app.control.VirtualCursorController

/**
 * GLSurfaceView that hosts the SBSRenderer and forwards
 * touch / joystick-driven cursor updates.
 */
class VRGLSurfaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : GLSurfaceView(context, attrs) {

    val renderer: SBSRenderer = SBSRenderer(context)
    private val cursorController = VirtualCursorController()

    init {
        setEGLContextClientVersion(2)
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        // Also allow touch testing of cursor when not using joystick
        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val nx = event.x / width
                val ny = event.y / height
                renderer.updateCursor(nx, ny)
                cursorController.updatePosition(nx, ny)
            }
        }
        return true
    }

    fun applySettings(
        scale: Float,
        distance: Float,
        curved: Boolean,
        distortion: Float
    ) {
        queueEvent {
            renderer.screenScale = scale
            renderer.screenDistance = distance
            renderer.isCurved = curved
            renderer.distortionStrength = distortion
        }
    }

    fun setSeat(yaw: Float, pitch: Float, distance: Float) {
        queueEvent {
            renderer.setSeat(yaw, pitch, distance)
        }
    }
}
