package com.vrmode.app.control

import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import com.vrmode.app.service.VRAccessibilityService
import com.vrmode.app.utils.PrefsManager

/**
 * Maps joystick / gamepad buttons and axes to phone actions.
 * Mapping is stored in SharedPreferences so user can customize everything.
 */
object JoystickMapper {

    // Preference keys for each action
    object Actions {
        const val CLICK = "map_click"
        const val BACK = "map_back"
        const val HOME = "map_home"
        const val RECENTS = "map_recents"
        const val VOLUME_UP = "map_vol_up"
        const val VOLUME_DOWN = "map_vol_down"
        const val BRIGHTNESS_UP = "map_bright_up"
        const val BRIGHTNESS_DOWN = "map_bright_down"
        const val NEXT = "map_next"
        const val PREVIOUS = "map_prev"
        const val PLAY_PAUSE = "map_play_pause"
        const val RECENTER = "map_recenter"
        const val EXIT_VR = "map_exit_vr"
        const val APP_LAUNCHER = "map_launcher"
    }

    // Default key codes (can be changed by user)
    private val defaultMap = mapOf(
        Actions.CLICK to KeyEvent.KEYCODE_BUTTON_A,
        Actions.BACK to KeyEvent.KEYCODE_BUTTON_B,
        Actions.HOME to KeyEvent.KEYCODE_BUTTON_MODE,
        Actions.RECENTS to KeyEvent.KEYCODE_BUTTON_SELECT,
        Actions.VOLUME_UP to KeyEvent.KEYCODE_DPAD_UP,
        Actions.VOLUME_DOWN to KeyEvent.KEYCODE_DPAD_DOWN,
        Actions.PLAY_PAUSE to KeyEvent.KEYCODE_BUTTON_X,
        Actions.RECENTER to KeyEvent.KEYCODE_BUTTON_Y,
        Actions.EXIT_VR to KeyEvent.KEYCODE_BUTTON_START
    )

    fun getMappedKeyCode(action: String): Int {
        return PrefsManager.getInt(action, defaultMap[action] ?: -1)
    }

    fun setMappedKeyCode(action: String, keyCode: Int) {
        PrefsManager.putInt(action, keyCode)
    }

    /**
     * Call this from any Activity / Service that receives KeyEvents
     * when a gamepad is connected.
     */
    fun handleKeyEvent(event: KeyEvent): Boolean {
        if (!PrefsManager.getBoolean(PrefsManager.KEY_ENABLE_JOYSTICK, true)) return false
        if (event.action != KeyEvent.ACTION_DOWN) return false

        val keyCode = event.keyCode
        val service = VRAccessibilityService.instance ?: return false

        return when (keyCode) {
            getMappedKeyCode(Actions.CLICK) -> {
                // Center click for now – real cursor position needs tracking
                service.performClick(500f, 1000f)
                true
            }
            getMappedKeyCode(Actions.BACK) -> {
                service.performGlobalBack()
                true
            }
            getMappedKeyCode(Actions.HOME) -> {
                service.performGlobalHome()
                true
            }
            getMappedKeyCode(Actions.RECENTS) -> {
                service.performGlobalRecents()
                true
            }
            getMappedKeyCode(Actions.EXIT_VR) -> {
                // Caller should stop VRModeService
                true
            }
            else -> false
        }
    }

    fun isGameController(device: InputDevice?): Boolean {
        if (device == null) return false
        val sources = device.sources
        return (sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                (sources and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
    }
}
