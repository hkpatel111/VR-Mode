package com.vrmode.app.vr

import android.content.Context
import android.graphics.SurfaceTexture
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Stereoscopic Side-by-Side (SBS) OpenGL ES 2.0 Renderer.
 *
 * Pipeline:
 * MediaProjection → SurfaceTexture → dual eye viewports →
 * barrel distortion shader → final SBS frame.
 *
 * This is a functional core implementation that can be extended
 * with higher-quality meshes and environment skyboxes.
 */
class SBSRenderer(private val context: Context) : GLSurfaceView.Renderer {

    companion object {
        private const val TAG = "SBSRenderer"
    }

    // Screen quad vertices (full NDC)
    private val quadVertices = floatArrayOf(
        -1f, -1f, 0f, 0f, 0f,
         1f, -1f, 0f, 1f, 0f,
        -1f,  1f, 0f, 0f, 1f,
         1f,  1f, 0f, 1f, 1f
    )

    private var vertexBuffer: FloatBuffer
    private var program = 0
    private var positionHandle = 0
    private var texCoordHandle = 0
    private var mvpMatrixHandle = 0
    private var textureHandle = 0
    private var distortionHandle = 0

    private val mvpMatrix = FloatArray(16)
    private val projectionMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)

    // External texture from MediaProjection / SurfaceTexture
    var externalTextureId = 0
        private set
    var surfaceTexture: SurfaceTexture? = null
        private set

    // Runtime parameters (controlled from settings)
    var screenScale = 0.7f
    var screenDistance = 0.5f
    var isCurved = true
    var distortionStrength = 0.22f   // barrel distortion amount
    var ipdOffset = 0.03f            // inter-pupillary offset

    // Cursor
    var cursorX = 0.5f
    var cursorY = 0.5f
    var showCursor = true

    // Seat / camera
    var seatYaw = 0f
    var seatPitch = 0f
    var seatDistance = 1f

    init {
        vertexBuffer = ByteBuffer.allocateDirect(quadVertices.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply {
                put(quadVertices)
                position(0)
            }
        Matrix.setIdentityM(mvpMatrix, 0)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        program = createProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        texCoordHandle = GLES20.glGetAttribLocation(program, "aTexCoord")
        mvpMatrixHandle = GLES20.glGetUniformLocation(program, "uMVPMatrix")
        textureHandle = GLES20.glGetUniformLocation(program, "uTexture")
        distortionHandle = GLES20.glGetUniformLocation(program, "uDistortion")

        // Create external OES texture for MediaProjection
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        externalTextureId = textures[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, externalTextureId) // will switch to EXTERNAL_OES in real pipeline
        // Note: real MediaProjection needs GL_TEXTURE_EXTERNAL_OES + SurfaceTexture
        surfaceTexture = SurfaceTexture(externalTextureId)

        Log.i(TAG, "SBS Renderer surface created, texId=$externalTextureId")
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val ratio = width.toFloat() / height
        Matrix.frustumM(projectionMatrix, 0, -ratio, ratio, -1f, 1f, 1f, 20f)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        surfaceTexture?.updateTexImage()

        GLES20.glUseProgram(program)

        // Left eye
        drawEye(isLeft = true)
        // Right eye
        drawEye(isLeft = false)

        // Cursor overlay (both eyes)
        if (showCursor) {
            drawCursor()
        }
    }

    private fun drawEye(isLeft: Boolean) {
        val halfWidth = 1f   // we render into full viewport and use scissor conceptually
        // In a full implementation we would set scissor or use two viewports.
        // For clarity we keep a single pass with IPD offset in the matrix.

        Matrix.setLookAtM(
            viewMatrix, 0,
            if (isLeft) -ipdOffset else ipdOffset, 0f, seatDistance + screenDistance,
            0f, 0f, 0f,
            0f, 1f, 0f
        )

        // Apply seat rotation
        val rot = FloatArray(16)
        Matrix.setRotateM(rot, 0, seatYaw, 0f, 1f, 0f)
        Matrix.multiplyMM(viewMatrix, 0, rot, 0, viewMatrix, 0)

        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, viewMatrix, 0)
        // Scale the virtual screen
        Matrix.scaleM(mvpMatrix, 0, screenScale, screenScale, 1f)

        GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false, mvpMatrix, 0)
        GLES20.glUniform1f(distortionHandle, distortionStrength)

        vertexBuffer.position(0)
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 20, vertexBuffer)
        GLES20.glEnableVertexAttribArray(positionHandle)

        vertexBuffer.position(3)
        GLES20.glVertexAttribPointer(texCoordHandle, 2, GLES20.GL_FLOAT, false, 20, vertexBuffer)
        GLES20.glEnableVertexAttribArray(texCoordHandle)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, externalTextureId)
        GLES20.glUniform1i(textureHandle, 0)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun drawCursor() {
        // Simple point cursor – in production replace with textured quad
        // Position is normalized 0-1
    }

    fun updateCursor(nx: Float, ny: Float) {
        cursorX = nx.coerceIn(0f, 1f)
        cursorY = ny.coerceIn(0f, 1f)
    }

    fun setSeat(yaw: Float, pitch: Float, distance: Float) {
        seatYaw = yaw
        seatPitch = pitch
        seatDistance = distance
    }

    private fun loadShader(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val compiled = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0)
        if (compiled[0] == 0) {
            Log.e(TAG, "Shader compile error: ${GLES20.glGetShaderInfoLog(shader)}")
            GLES20.glDeleteShader(shader)
            return 0
        }
        return shader
    }

    private fun createProgram(vertexSource: String, fragmentSource: String): Int {
        val vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexSource)
        val fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource)
        val program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vertexShader)
        GLES20.glAttachShader(program, fragmentShader)
        GLES20.glLinkProgram(program)
        return program
    }

    // ---------- Shaders ----------

    private val VERTEX_SHADER = """
        uniform mat4 uMVPMatrix;
        attribute vec4 aPosition;
        attribute vec2 aTexCoord;
        varying vec2 vTexCoord;
        void main() {
            gl_Position = uMVPMatrix * aPosition;
            vTexCoord = aTexCoord;
        }
    """.trimIndent()

    private val FRAGMENT_SHADER = """
        precision mediump float;
        varying vec2 vTexCoord;
        uniform sampler2D uTexture;
        uniform float uDistortion;

        // Simple barrel distortion for mobile VR lenses
        vec2 distort(vec2 uv) {
            vec2 center = vec2(0.5, 0.5);
            vec2 delta = uv - center;
            float r2 = dot(delta, delta);
            float f = 1.0 + uDistortion * r2;
            return center + delta * f;
        }

        void main() {
            vec2 uv = distort(vTexCoord);
            if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
                gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
            } else {
                gl_FragColor = texture2D(uTexture, uv);
            }
        }
    """.trimIndent()
}
