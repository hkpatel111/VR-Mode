package com.vrmode.app.service

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.util.Log
import com.vrmode.app.ui.MainActivity
import com.vrmode.app.utils.PrefsManager

/**
 * Quick Settings Tile for enabling / disabling VR Mode.
 * Tapping the tile opens MainActivity if MediaProjection permission is needed,
 * or toggles the service if already authorized.
 */
class VRModeTileService : TileService() {

    companion object {
        private const val TAG = "VRModeTile"
    }

    override fun onStartListening() {
        super.onStartListening()
        updateTileState()
    }

    override fun onClick() {
        super.onClick()
        val isOn = PrefsManager.isVREnabled() || VRModeService.isRunning

        if (isOn) {
            // Turn OFF
            val stopIntent = Intent(this, VRModeService::class.java).apply {
                action = VRModeService.ACTION_STOP
            }
            startService(stopIntent)
            PrefsManager.setVREnabled(false)
        } else {
            // Turn ON → open MainActivity so user can Apply (MediaProjection needs UI)
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("from_quick_settings", true)
            }
            startActivityAndCollapse(intent)
        }
        updateTileState()
    }

    private fun updateTileState() {
        val tile = qsTile ?: return
        val isOn = PrefsManager.isVREnabled() || VRModeService.isRunning
        tile.state = if (isOn) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = if (isOn) "VR Mode ON" else "VR Mode"
        tile.updateTile()
        Log.d(TAG, "Tile updated → isOn=$isOn")
    }
}
