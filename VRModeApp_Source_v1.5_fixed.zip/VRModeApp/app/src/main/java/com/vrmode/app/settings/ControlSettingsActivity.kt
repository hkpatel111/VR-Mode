package com.vrmode.app.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.vrmode.app.databinding.ActivityControlSettingsBinding
import com.vrmode.app.utils.PrefsManager

class ControlSettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityControlSettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityControlSettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Control Sources"

        binding.switchJoystick.isChecked = PrefsManager.getBoolean(PrefsManager.KEY_ENABLE_JOYSTICK, true)
        binding.switchVolumeButtons.isChecked = PrefsManager.getBoolean(PrefsManager.KEY_ENABLE_VOLUME_BUTTONS, true)
        binding.switchHeadGestures.isChecked = PrefsManager.getBoolean(PrefsManager.KEY_ENABLE_HEAD_GESTURES, false)
        binding.switchVoice.isChecked = PrefsManager.getBoolean(PrefsManager.KEY_ENABLE_VOICE, false)

        binding.switchJoystick.setOnCheckedChangeListener { _, checked ->
            PrefsManager.putBoolean(PrefsManager.KEY_ENABLE_JOYSTICK, checked)
        }
        binding.switchVolumeButtons.setOnCheckedChangeListener { _, checked ->
            PrefsManager.putBoolean(PrefsManager.KEY_ENABLE_VOLUME_BUTTONS, checked)
        }
        binding.switchHeadGestures.setOnCheckedChangeListener { _, checked ->
            PrefsManager.putBoolean(PrefsManager.KEY_ENABLE_HEAD_GESTURES, checked)
        }
        binding.switchVoice.setOnCheckedChangeListener { _, checked ->
            PrefsManager.putBoolean(PrefsManager.KEY_ENABLE_VOICE, checked)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
