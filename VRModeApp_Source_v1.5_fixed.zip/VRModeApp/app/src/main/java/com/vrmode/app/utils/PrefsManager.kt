package com.vrmode.app.utils

import android.content.Context
import android.content.SharedPreferences

object PrefsManager {

    private const val PREFS_NAME = "vr_mode_prefs"
    private lateinit var prefs: SharedPreferences

    // Keys
    const val KEY_ENVIRONMENT = "environment"
    const val KEY_SCREEN_SIZE = "screen_size"
    const val KEY_SCREEN_DISTANCE = "screen_distance"
    const val KEY_CURVED = "curved_screen"
    const val KEY_BRIGHTNESS = "brightness"
    const val KEY_CONTRAST = "contrast"
    const val KEY_RESOLUTION = "resolution"
    const val KEY_FPS = "fps"
    const val KEY_AMBIENT_VOLUME = "ambient_volume"
    const val KEY_NIGHT_MODE = "night_mode"
    const val KEY_AUTO_HIDE_CONTROLS = "auto_hide_controls"
    const val KEY_VR_ENABLED = "vr_enabled"

    // Control sources
    const val KEY_ENABLE_JOYSTICK = "enable_joystick"
    const val KEY_ENABLE_VOLUME_BUTTONS = "enable_volume_buttons"
    const val KEY_ENABLE_HEAD_GESTURES = "enable_head_gestures"
    const val KEY_ENABLE_VOICE = "enable_voice"

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun getString(key: String, default: String = ""): String =
        prefs.getString(key, default) ?: default

    fun putString(key: String, value: String) =
        prefs.edit().putString(key, value).apply()

    fun getInt(key: String, default: Int = 0): Int =
        prefs.getInt(key, default)

    fun putInt(key: String, value: Int) =
        prefs.edit().putInt(key, value).apply()

    fun getBoolean(key: String, default: Boolean = false): Boolean =
        prefs.getBoolean(key, default)

    fun putBoolean(key: String, value: Boolean) =
        prefs.edit().putBoolean(key, value).apply()

    fun getFloat(key: String, default: Float = 0f): Float =
        prefs.getFloat(key, default)

    fun putFloat(key: String, value: Float) =
        prefs.edit().putFloat(key, value).apply()

    // Environment helpers
    fun getCurrentEnvironment(): String =
        getString(KEY_ENVIRONMENT, "Classic Movie Theater")

    fun setCurrentEnvironment(name: String) =
        putString(KEY_ENVIRONMENT, name)

    fun isVREnabled(): Boolean = getBoolean(KEY_VR_ENABLED, false)

    fun setVREnabled(enabled: Boolean) =
        putBoolean(KEY_VR_ENABLED, enabled)
}
