package com.vrmode.app.utils

data class VREnvironment(
    val id: String,
    val name: String,
    val category: String,
    val description: String,
    val ambientSoundRes: String? = null,   // asset or raw name
    val supportsSeatSelection: Boolean = true,
    val defaultCurved: Boolean = true
)

object EnvironmentRepository {

    val allEnvironments = listOf(
        VREnvironment("classic_theater", "Classic Movie Theater", "Cinema",
            "Traditional cinema hall with red seats, curtains and ambient lighting"),
        VREnvironment("imax", "IMAX Giant Screen", "Cinema",
            "Massive curved IMAX-style screen with premium seating"),
        VREnvironment("home_theater", "Luxury Home Theater", "Cinema",
            "Modern private home cinema with comfortable recliners"),
        VREnvironment("drive_in", "1960s Drive-In Theater", "Outdoor",
            "Classic American drive-in with cars, neon lights and night sky"),
        VREnvironment("moonlight_beach", "Moonlight Beach", "Outdoor",
            "Tropical beach at night with gentle waves and stars"),
        VREnvironment("lakeside", "Lakeside / Winter Lake View", "Outdoor",
            "Peaceful lake with mountains (Irusu style)"),
        VREnvironment("mountain", "Mountain Viewpoint", "Outdoor",
            "High-altitude scenic view with open sky"),
        VREnvironment("haunted", "Haunted House", "Themed",
            "Dark atmospheric haunted mansion"),
        VREnvironment("spaceship", "Spaceship / Space Station", "Themed",
            "Futuristic spaceship interior with starfield"),
        VREnvironment("ancient", "Ancient Theater", "Themed",
            "Open-air classical amphitheater"),
        VREnvironment("void", "Pure Void", "Minimal",
            "Completely black void for maximum focus", supportsSeatSelection = false, defaultCurved = false),
        VREnvironment("fullscreen", "Full Screen Mode", "Minimal",
            "Screen fills entire view", supportsSeatSelection = false, defaultCurved = false),
        VREnvironment("apartment", "Luxury Apartment", "Premium",
            "Modern apartment living room with large TV"),
        VREnvironment("yacht", "Private Yacht Deck", "Premium",
            "Outdoor deck of a luxury yacht at sunset")
    )

    fun getById(id: String): VREnvironment? = allEnvironments.find { it.id == id }
    fun getByName(name: String): VREnvironment? = allEnvironments.find { it.name == name }
}
