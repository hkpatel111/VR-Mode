package com.vrmode.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.vrmode.app.utils.PrefsManager

class VRModeApp : Application() {

    companion object {
        const val CHANNEL_ID = "vr_mode_channel"
        const val CHANNEL_NAME = "VR Mode Status"
        lateinit var instance: VRModeApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        PrefsManager.init(this)
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows VR Mode status and quick toggle"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
}
