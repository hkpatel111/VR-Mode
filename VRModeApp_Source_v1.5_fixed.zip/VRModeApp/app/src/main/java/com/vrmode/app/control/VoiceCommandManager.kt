package com.vrmode.app.control

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import com.vrmode.app.utils.PrefsManager
import java.util.Locale

/**
 * Voice command recognition for VR Mode.
 * Supported commands (English + simple Hindi variants):
 * - "exit vr" / "stop vr" / "band karo"
 * - "recenter" / "center"
 * - "next seat" / "previous seat"
 * - "volume up" / "volume down"
 * - "home" / "back"
 */
class VoiceCommandManager(private val context: Context) : RecognitionListener {

    companion object {
        private const val TAG = "VoiceCommand"
    }

    interface CommandListener {
        fun onExitVR()
        fun onRecenter()
        fun onNextSeat()
        fun onPreviousSeat()
        fun onVolumeUp()
        fun onVolumeDown()
        fun onHome()
        fun onBack()
        fun onUnknown(text: String)
    }

    var listener: CommandListener? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false

    fun init() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.w(TAG, "Speech recognition not available on this device")
            return
        }
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(this@VoiceCommandManager)
        }
    }

    fun startListening() {
        if (!PrefsManager.getBoolean(PrefsManager.KEY_ENABLE_VOICE, false)) return
        if (speechRecognizer == null) init()
        if (isListening) return

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        speechRecognizer?.startListening(intent)
        isListening = true
        Log.i(TAG, "Started listening")
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
        isListening = false
    }

    fun destroy() {
        stopListening()
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    override fun onResults(results: Bundle?) {
        isListening = false
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
        val text = matches.firstOrNull()?.lowercase(Locale.getDefault()) ?: return
        Log.d(TAG, "Recognized: $text")
        dispatchCommand(text)
    }

    private fun dispatchCommand(text: String) {
        when {
            text.contains("exit") || text.contains("stop vr") || text.contains("band karo") ||
            text.contains("band kar") || text.contains("close vr") -> listener?.onExitVR()

            text.contains("recenter") || text.contains("center") || text.contains("reset view") ->
                listener?.onRecenter()

            text.contains("next seat") || text.contains("aage seat") -> listener?.onNextSeat()
            text.contains("previous seat") || text.contains("pichle seat") || text.contains("back seat") ->
                listener?.onPreviousSeat()

            text.contains("volume up") || text.contains("awaz badhao") -> listener?.onVolumeUp()
            text.contains("volume down") || text.contains("awaz kam") -> listener?.onVolumeDown()

            text.contains("home") || text.contains("ghar") -> listener?.onHome()
            text.contains("back") || text.contains("peeche") || text.contains("wapas") -> listener?.onBack()

            else -> listener?.onUnknown(text)
        }
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() { isListening = false }
    override fun onError(error: Int) {
        isListening = false
        Log.w(TAG, "Speech error code: $error")
    }
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
}
