package com.vrmode.app.vr

import android.content.Context
import android.util.Log
import com.vrmode.app.utils.EnvironmentRepository

/**
 * Manages 3D environment assets (skyboxes / simple room models).
 *
 * In this build we provide a clear asset contract and placeholder loaders.
 * Real GLB / cubemap files should be placed under:
 *   assets/environments/<env_id>/
 *     skybox_right.png ... (or a single equirectangular)
 *     room.glb (optional)
 *
 * The loader returns a descriptor that the renderer can use.
 */
class EnvironmentAssetManager(private val context: Context) {

    companion object {
        private const val TAG = "EnvAssets"
        private const val BASE_PATH = "environments"
    }

    data class EnvironmentAssets(
        val envId: String,
        val hasSkybox: Boolean,
        val hasRoomModel: Boolean,
        val skyboxPath: String?,
        val roomModelPath: String?,
        val ambientColorHint: FloatArray = floatArrayOf(0.1f, 0.1f, 0.12f)
    )

    private val cache = mutableMapOf<String, EnvironmentAssets>()

    fun load(envId: String): EnvironmentAssets {
        cache[envId]?.let { return it }

        val skybox = "$BASE_PATH/$envId/skybox.jpg"
        val room = "$BASE_PATH/$envId/room.glb"

        val hasSkybox = assetExists(skybox)
        val hasRoom = assetExists(room)

        val assets = EnvironmentAssets(
            envId = envId,
            hasSkybox = hasSkybox,
            hasRoomModel = hasRoom,
            skyboxPath = if (hasSkybox) skybox else null,
            roomModelPath = if (hasRoom) room else null,
            ambientColorHint = defaultAmbientFor(envId)
        )
        cache[envId] = assets
        Log.i(TAG, "Loaded descriptor for $envId (skybox=$hasSkybox, room=$hasRoom)")
        return assets
    }

    fun loadByName(name: String): EnvironmentAssets? {
        val env = EnvironmentRepository.getByName(name) ?: return null
        return load(env.id)
    }

    private fun assetExists(path: String): Boolean {
        return try {
            context.assets.open(path).close()
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun defaultAmbientFor(envId: String): FloatArray = when (envId) {
        "classic_theater", "imax", "home_theater" -> floatArrayOf(0.12f, 0.10f, 0.09f)
        "drive_in", "moonlight_beach", "lakeside", "mountain" -> floatArrayOf(0.08f, 0.10f, 0.18f)
        "haunted" -> floatArrayOf(0.05f, 0.04f, 0.06f)
        "spaceship" -> floatArrayOf(0.06f, 0.08f, 0.14f)
        "ancient" -> floatArrayOf(0.14f, 0.12f, 0.09f)
        "apartment", "yacht" -> floatArrayOf(0.15f, 0.14f, 0.13f)
        else -> floatArrayOf(0.05f, 0.05f, 0.05f) // void / fullscreen
    }

    /**
     * Call this once to pre-create folder structure hints (for developers).
     * Does not create real binary assets.
     */
    fun listExpectedAssetPaths(): List<String> {
        return EnvironmentRepository.allEnvironments.map { env ->
            "assets/$BASE_PATH/${env.id}/skybox.jpg  OR  room.glb"
        }
    }
}
