package com.vrmode.app.ui

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.vrmode.app.R
import com.vrmode.app.databinding.ActivityMainBinding
import com.vrmode.app.service.VRModeService
import com.vrmode.app.settings.ControlSettingsActivity
import com.vrmode.app.settings.JoystickMappingActivity
import com.vrmode.app.utils.EnvironmentRepository
import com.vrmode.app.utils.PrefsManager

/**
 * Main setup screen.
 * Top  → Live Preview area (placeholder for now)
 * Bottom → All settings
 * Apply button → requests MediaProjection and starts VRModeService
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, VRModeService::class.java).apply {
                action = VRModeService.ACTION_START
                putExtra(VRModeService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(VRModeService.EXTRA_DATA, result.data)
            }
            startForegroundService(serviceIntent)
            Toast.makeText(this, "VR Mode Enabled", Toast.LENGTH_SHORT).show()
            // Optionally finish or keep the settings screen
        } else {
            Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupEnvironmentSpinner()
        loadSavedSettings()
        setupListeners()

        // If opened from Quick Settings tile
        if (intent.getBooleanExtra("from_quick_settings", false)) {
            Toast.makeText(this, "Tap Apply to enable VR Mode", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupEnvironmentSpinner() {
        val names = EnvironmentRepository.allEnvironments.map { it.name }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        binding.spinnerEnvironment.adapter = adapter

        val current = PrefsManager.getCurrentEnvironment()
        val index = names.indexOf(current).coerceAtLeast(0)
        binding.spinnerEnvironment.setSelection(index)
    }

    private fun loadSavedSettings() {
        binding.seekScreenSize.progress = PrefsManager.getInt(PrefsManager.KEY_SCREEN_SIZE, 70)
        binding.seekDistance.progress = PrefsManager.getInt(PrefsManager.KEY_SCREEN_DISTANCE, 50)
        binding.switchCurved.isChecked = PrefsManager.getBoolean(PrefsManager.KEY_CURVED, true)
        binding.switchNightMode.isChecked = PrefsManager.getBoolean(PrefsManager.KEY_NIGHT_MODE, false)
        binding.switchAutoHide.isChecked = PrefsManager.getBoolean(PrefsManager.KEY_AUTO_HIDE_CONTROLS, true)
        updatePreviewText()
    }

    private fun setupListeners() {
        // Live preview updates
        binding.spinnerEnvironment.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val name = EnvironmentRepository.allEnvironments[position].name
                PrefsManager.setCurrentEnvironment(name)
                updatePreviewText()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        })

        binding.seekScreenSize.setOnSeekBarChangeListener(simpleSeekListener {
            PrefsManager.putInt(PrefsManager.KEY_SCREEN_SIZE, it)
            updatePreviewText()
        })
        binding.seekDistance.setOnSeekBarChangeListener(simpleSeekListener {
            PrefsManager.putInt(PrefsManager.KEY_SCREEN_DISTANCE, it)
            updatePreviewText()
        })
        binding.switchCurved.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.putBoolean(PrefsManager.KEY_CURVED, isChecked)
            updatePreviewText()
        }
        binding.switchNightMode.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.putBoolean(PrefsManager.KEY_NIGHT_MODE, isChecked)
        }
        binding.switchAutoHide.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.putBoolean(PrefsManager.KEY_AUTO_HIDE_CONTROLS, isChecked)
        }

        binding.btnJoystickMapping.setOnClickListener {
            startActivity(Intent(this, JoystickMappingActivity::class.java))
        }
        binding.btnControlSettings.setOnClickListener {
            startActivity(Intent(this, ControlSettingsActivity::class.java))
        }
        binding.btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnApply.setOnClickListener {
            requestMediaProjectionAndStart()
        }
    }

    private fun updatePreviewText() {
        val env = PrefsManager.getCurrentEnvironment()
        val size = PrefsManager.getInt(PrefsManager.KEY_SCREEN_SIZE, 70)
        val dist = PrefsManager.getInt(PrefsManager.KEY_SCREEN_DISTANCE, 50)
        val curved = if (PrefsManager.getBoolean(PrefsManager.KEY_CURVED, true)) "Curved" else "Flat"
        binding.tvPreviewInfo.text = """
            Environment: $env
            Screen Size: $size%
            Distance: $dist%
            Shape: $curved
            
            (Live 3D preview will appear here in next builds)
        """.trimIndent()
    }

    private fun requestMediaProjectionAndStart() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun simpleSeekListener(onChange: (Int) -> Unit) =
        object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) onChange(progress)
            }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        }
}
