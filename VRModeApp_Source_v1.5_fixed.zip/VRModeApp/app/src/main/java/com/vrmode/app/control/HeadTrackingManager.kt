package com.vrmode.app.control

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.Log
import com.vrmode.app.utils.PrefsManager
import kotlin.math.abs

/**
 * Head-tracking gesture engine using gyroscope + rotation vector.
 * Detects simple gestures (nod, shake, tilt) that can be mapped
 * to actions such as Recenter, Next Seat, Back, etc.
 */
class HeadTrackingManager(context: Context) : SensorEventListener {

    companion object {
        private const val TAG = "HeadTracking"
        private const val NOD_THRESHOLD = 0.45f
        private const val SHAKE_THRESHOLD = 0.6f
        private const val TILT_THRESHOLD = 0.35f
        private const val COOLDOWN_MS = 800L
    }

    interface GestureListener {
        fun onNod()           // usually Recenter or Confirm
        fun onShake()         // usually Back / Cancel
        fun onTiltLeft()
        fun onTiltRight()
        fun onLookUp()
        fun onLookDown()
    }

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val gyroSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    var listener: GestureListener? = null
    private var lastGestureTime = 0L
    private var enabled = true

    // Current orientation (approx yaw/pitch/roll in radians)
    var yaw = 0f; private set
    var pitch = 0f; private set
    var roll = 0f; private set

    private val rotationMatrix = FloatArray(9)
    private val orientation = FloatArray(3)

    fun start() {
        enabled = PrefsManager.getBoolean(PrefsManager.KEY_ENABLE_HEAD_GESTURES, false)
        if (!enabled) return
        rotationSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        gyroSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        Log.i(TAG, "Head tracking started")
    }

    fun stop() {
        sensorManager.unregisterListener(this)
        Log.i(TAG, "Head tracking stopped")
    }

    fun setEnabled(value: Boolean) {
        enabled = value
        PrefsManager.putBoolean(PrefsManager.KEY_ENABLE_HEAD_GESTURES, value)
        if (value) start() else stop()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (!enabled) return

        when (event.sensor.type) {
            Sensor.TYPE_ROTATION_VECTOR -> {
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                SensorManager.getOrientation(rotationMatrix, orientation)
                // orientation: [azimuth (yaw), pitch, roll]
                yaw = orientation[0]
                pitch = orientation[1]
                roll = orientation[2]
                detectOrientationGestures()
            }
            Sensor.TYPE_GYROSCOPE -> {
                detectGyroGestures(event.values[0], event.values[1], event.values[2])
            }
        }
    }

    private fun detectOrientationGestures() {
        val now = System.currentTimeMillis()
        if (now - lastGestureTime < COOLDOWN_MS) return

        when {
            pitch < -TILT_THRESHOLD -> {
                lastGestureTime = now
                listener?.onLookDown()
            }
            pitch > TILT_THRESHOLD -> {
                lastGestureTime = now
                listener?.onLookUp()
            }
            roll < -TILT_THRESHOLD -> {
                lastGestureTime = now
                listener?.onTiltLeft()
            }
            roll > TILT_THRESHOLD -> {
                lastGestureTime = now
                listener?.onTiltRight()
            }
        }
    }

    private fun detectGyroGestures(x: Float, y: Float, z: Float) {
        val now = System.currentTimeMillis()
        if (now - lastGestureTime < COOLDOWN_MS) return

        // Simple nod (rotation around X) and shake (around Y)
        if (abs(x) > NOD_THRESHOLD) {
            lastGestureTime = now
            listener?.onNod()
        } else if (abs(y) > SHAKE_THRESHOLD) {
            lastGestureTime = now
            listener?.onShake()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
