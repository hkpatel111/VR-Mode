package com.vrmode.app.vr

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.util.Log
import com.vrmode.app.utils.EnvironmentRepository
import com.vrmode.app.utils.PrefsManager

/**
 * Plays environment-matched ambient loops.
 * In this core build we register logical ambient IDs.
 * Real .ogg assets should be placed in res/raw/ and mapped here.
 *
 * Spatial feel is approximated by stereo volume balance;
 * full HRTF spatial audio can be added later with Oboe / AAudio.
 */
class AmbientSoundManager(private val context: Context) {

    companion object {
        private const val TAG = "AmbientSound"
    }

    private var soundPool: SoundPool? = null
    private val soundIds = mutableMapOf<String, Int>()
    private var currentStreamId = 0
    private var currentEnvId: String? = null

    fun init() {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        soundPool = SoundPool.Builder()
            .setMaxStreams(2)
            .setAudioAttributes(attrs)
            .build()

        // Map environment IDs to raw resources when assets are added.
        // Example (uncomment when files exist):
        // soundIds["classic_theater"] = soundPool!!.load(context, R.raw.ambient_cinema, 1)
        // soundIds["drive_in"] = soundPool!!.load(context, R.raw.ambient_drivein, 1)
        // ...
        Log.i(TAG, "AmbientSoundManager initialized (assets pending)")
    }

    fun playForEnvironment(envName: String) {
        val env = EnvironmentRepository.getByName(envName) ?: return
        if (env.id == currentEnvId) return

        stop()
        currentEnvId = env.id

        val soundId = soundIds[env.id] ?: return
        val volume = PrefsManager.getFloat(PrefsManager.KEY_AMBIENT_VOLUME, 0.4f)
        currentStreamId = soundPool?.play(soundId, volume, volume, 1, -1, 1f) ?: 0
        Log.i(TAG, "Playing ambient for ${env.name}")
    }

    fun setVolume(volume: Float) {
        val v = volume.coerceIn(0f, 1f)
        PrefsManager.putFloat(PrefsManager.KEY_AMBIENT_VOLUME, v)
        if (currentStreamId != 0) {
            soundPool?.setVolume(currentStreamId, v, v)
        }
    }

    fun stop() {
        if (currentStreamId != 0) {
            soundPool?.stop(currentStreamId)
            currentStreamId = 0
        }
        currentEnvId = null
    }

    fun release() {
        stop()
        soundPool?.release()
        soundPool = null
    }
}
