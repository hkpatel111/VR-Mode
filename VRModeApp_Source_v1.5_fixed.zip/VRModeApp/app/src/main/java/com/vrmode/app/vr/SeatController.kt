package com.vrmode.app.vr

/**
 * Manages seat selection and smooth camera movement
 * between different viewing positions inside an environment.
 *
 * Inspired by Irusu Player Pro seat selection.
 */
class SeatController {

    data class Seat(
        val id: Int,
        val name: String,
        val yaw: Float,      // degrees
        val pitch: Float,
        val distance: Float, // relative
        val description: String
    )

    // Typical cinema seats
    private val cinemaSeats = listOf(
        Seat(0, "Center Front", 0f, -5f, 0.85f, "Closest to the screen, center"),
        Seat(1, "Center Middle", 0f, 0f, 1.0f, "Balanced view"),
        Seat(2, "Center Back", 0f, 3f, 1.25f, "Relaxed distant view"),
        Seat(3, "Left Middle", -18f, 0f, 1.05f, "Left side angle"),
        Seat(4, "Right Middle", 18f, 0f, 1.05f, "Right side angle"),
        Seat(5, "Left Back", -25f, 4f, 1.3f, "Wide left perspective"),
        Seat(6, "Right Back", 25f, 4f, 1.3f, "Wide right perspective")
    )

    private var currentSeatIndex = 1
    private var targetYaw = 0f
    private var targetPitch = 0f
    private var targetDistance = 1f
    private var currentYaw = 0f
    private var currentPitch = 0f
    private var currentDistance = 1f

    val seats: List<Seat> get() = cinemaSeats
    val currentSeat: Seat get() = cinemaSeats[currentSeatIndex]

    fun selectSeat(index: Int) {
        if (index !in cinemaSeats.indices) return
        currentSeatIndex = index
        val seat = cinemaSeats[index]
        targetYaw = seat.yaw
        targetPitch = seat.pitch
        targetDistance = seat.distance
    }

    fun selectNext() {
        selectSeat((currentSeatIndex + 1) % cinemaSeats.size)
    }

    fun selectPrevious() {
        selectSeat((currentSeatIndex - 1 + cinemaSeats.size) % cinemaSeats.size)
    }

    /**
     * Call every frame to smoothly interpolate camera toward target seat.
     * Returns the current interpolated values.
     */
    fun update(deltaTime: Float): Triple<Float, Float, Float> {
        val speed = 3.5f * deltaTime
        currentYaw += (targetYaw - currentYaw) * speed
        currentPitch += (targetPitch - currentPitch) * speed
        currentDistance += (targetDistance - currentDistance) * speed
        return Triple(currentYaw, currentPitch, currentDistance)
    }

    fun snapToCurrent() {
        val seat = currentSeat
        currentYaw = seat.yaw
        currentPitch = seat.pitch
        currentDistance = seat.distance
        targetYaw = currentYaw
        targetPitch = currentPitch
        targetDistance = currentDistance
    }
}
