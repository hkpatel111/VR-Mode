package com.vrmode.app.control

import android.view.InputDevice
import android.view.MotionEvent
import com.vrmode.app.service.VRAccessibilityService
import com.vrmode.app.utils.PrefsManager
import kotlin.math.abs

/**
 * Continuous virtual cursor driven by joystick left stick.
 * Provides aim-assist (snapping toward nearby clickable areas – simplified)
 * and injects clicks via AccessibilityService.
 */
class VirtualCursorController {

    // Normalized position 0..1
    var x = 0.5f
        private set
    var y = 0.5f
        private set

    private var velocityX = 0f
    private var velocityY = 0f
    private val speed = 1.8f          // base movement speed
    private val aimAssistRadius = 0.08f
    private val damping = 0.85f

    fun updatePosition(nx: Float, ny: Float) {
        x = nx.coerceIn(0f, 1f)
        y = ny.coerceIn(0f, 1f)
    }

    /**
     * Call from onGenericMotionEvent when a joystick is present.
     */
    fun handleJoystickMotion(event: MotionEvent): Boolean {
        if (!PrefsManager.getBoolean(PrefsManager.KEY_ENABLE_JOYSTICK, true)) return false
        if (event.source and InputDevice.SOURCE_JOYSTICK != InputDevice.SOURCE_JOYSTICK &&
            event.source and InputDevice.SOURCE_GAMEPAD != InputDevice.SOURCE_GAMEPAD) {
            return false
        }

        val axisX = event.getAxisValue(MotionEvent.AXIS_X)
        val axisY = event.getAxisValue(MotionEvent.AXIS_Y)

        // Dead-zone
        val dead = 0.15f
        val dx = if (abs(axisX) > dead) axisX else 0f
        val dy = if (abs(axisY) > dead) axisY else 0f

        velocityX = dx * speed * 0.016f   // approx frame time
        velocityY = dy * speed * 0.016f

        x = (x + velocityX).coerceIn(0f, 1f)
        y = (y + velocityY).coerceIn(0f, 1f)

        // Simple damping when stick released
        if (dx == 0f && dy == 0f) {
            velocityX *= damping
            velocityY *= damping
        }

        // Aim assist could pull cursor toward nearest interactive node here
        // (requires Accessibility node search – left as extension point)

        return true
    }

    /**
     * Perform a click at current cursor position.
     * Screen coordinates must be calculated from normalized values
     * using real display metrics.
     */
    fun performClick(screenWidth: Int, screenHeight: Int) {
        val service = VRAccessibilityService.instance ?: return
        val px = x * screenWidth
        val py = y * screenHeight
        service.performClick(px, py)
    }

    fun getNormalizedPosition(): Pair<Float, Float> = x to y
}
