package com.vrmode.app.settings

import android.os.Bundle
import android.view.KeyEvent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.vrmode.app.control.JoystickMapper
import com.vrmode.app.databinding.ActivityJoystickMappingBinding

/**
 * Simple screen that lets user re-map joystick buttons.
 * Press a physical button on the controller while an action is selected.
 */
class JoystickMappingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityJoystickMappingBinding
    private var currentlyMappingAction: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityJoystickMappingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Joystick Mapping"

        setupButtons()
    }

    private fun setupButtons() {
        binding.btnMapClick.setOnClickListener { startMapping(JoystickMapper.Actions.CLICK, "Click / Select") }
        binding.btnMapBack.setOnClickListener { startMapping(JoystickMapper.Actions.BACK, "Back") }
        binding.btnMapHome.setOnClickListener { startMapping(JoystickMapper.Actions.HOME, "Home") }
        binding.btnMapRecents.setOnClickListener { startMapping(JoystickMapper.Actions.RECENTS, "Recents") }
        binding.btnMapExit.setOnClickListener { startMapping(JoystickMapper.Actions.EXIT_VR, "Exit VR Mode") }
        binding.btnMapRecenter.setOnClickListener { startMapping(JoystickMapper.Actions.RECENTER, "Recenter") }
    }

    private fun startMapping(action: String, label: String) {
        currentlyMappingAction = action
        binding.tvStatus.text = "Press a button on your joystick for: $label"
        Toast.makeText(this, "Waiting for button press…", Toast.LENGTH_SHORT).show()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val action = currentlyMappingAction
        if (action != null && event != null) {
            JoystickMapper.setMappedKeyCode(action, keyCode)
            binding.tvStatus.text = "Mapped! KeyCode $keyCode saved for $action"
            currentlyMappingAction = null
            Toast.makeText(this, "Button mapped successfully", Toast.LENGTH_SHORT).show()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
