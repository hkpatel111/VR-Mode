# VR Mode – Android Project

**Version:** 1.0 Core Skeleton  
**Package:** `com.vrmode.app`

This repository contains the **core project structure and working foundation** for the VR Mode application described in the project specification.

## What is included (working / ready)

- Complete Android project structure (Gradle, Manifest, resources)
- Main setup screen with **Live Preview area** + settings
- Environment list (14 realistic environments – Irusu style + more)
- **Quick Settings Tile** (`VRModeTileService`)
- Persistent Notification with **Turn Off VR Mode** action
- `VRModeService` (Foreground + MediaProjection ready)
- `VRAccessibilityService` (click, back, home, recents, swipe helpers)
- Joystick / Gamepad mapping system + dedicated mapping screen
- Control Sources settings (which inputs stay active)
- Preference manager for all settings
- Permission declarations for install / first-launch flow

## How to build APK

1. Open the project in **Android Studio** (Hedgehog or newer recommended)
2. Let Gradle sync
3. Connect a device or start an emulator (API 26+)
4. Build → Build Bundle(s) / APK(s) → Build APK(s)
5. Or from terminal:
   ```bash
   ./gradlew assembleDebug
   ```
   APK will be at `app/build/outputs/apk/debug/app-debug.apk`

## Important – What still needs implementation (Next Builds)

These are the more complex / rare parts that are **not fully implemented** in this core skeleton. They are clearly marked with `TODO` in code:

| Feature | Status | Notes |
|---------|--------|-------|
| Real stereoscopic SBS OpenGL / Vulkan renderer | Not implemented | Needs GLSurfaceView + dual eye cameras + barrel distortion shader |
| Live 3D environment rendering inside preview | Placeholder | Currently text-based preview only |
| Full cursor tracking + aim assist with joystick | Partial | Click helper exists, continuous cursor needs more work |
| Ambient spatial sound per environment | Not implemented | Assets + AudioTrack / SoundPool needed |
| Seat selection visual movement | Not implemented | Requires 3D camera paths |
| Head-tracking gestures | Flag only | Sensor fusion needed |
| Voice commands | Flag only | SpeechRecognizer integration needed |
| Dynamic lighting reacting to screen content | Not implemented | Advanced rendering |
| Real 3D environment assets (models / skyboxes) | Not included | Need to add GLB / skybox textures |

## Architecture Overview

```
com.vrmode.app
├── ui/                  → MainActivity (setup + live preview)
├── settings/            → JoystickMappingActivity, ControlSettingsActivity
├── service/             → VRModeService, VRModeTileService, VRAccessibilityService
├── control/             → JoystickMapper
├── vr/                  → VRDisplayActivity (future renderer host)
└── utils/               → PrefsManager, EnvironmentData, BootReceiver
```

## Permissions handled

All critical permissions are declared in the Manifest and requested at first launch / via system dialogs (MediaProjection + Accessibility).

## License

This core is provided for development of the VR Mode project.  
You can continue building the missing rendering and premium environment features on top of this foundation.
